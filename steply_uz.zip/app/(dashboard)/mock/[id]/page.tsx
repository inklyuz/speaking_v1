'use client'

import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowLeft, ArrowRight, CalendarDays, CheckCircle2, Clock3, MapPin, Users } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { publicApi } from '@/lib/api/endpoints'
import type { PublicExamDetail } from '@/lib/api/types'

export default function MockDetailPage() {
  const { id } = useParams<{ id: string }>()
  const [exam, setExam] = useState<PublicExamDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  useEffect(() => { publicApi.mockExam(id).then(setExam).catch(e=>setError(e instanceof Error?e.message:'Imtihon topilmadi')).finally(()=>setLoading(false)) }, [id])
  if (loading) return <div className="min-h-screen"><SiteHeader/><main className="container-shell py-16"><div className="surface h-80 animate-pulse"/></main></div>
  if (!exam) return <div className="min-h-screen"><SiteHeader/><main className="container-shell py-16"><div className="surface p-10 text-center"><h1 className="text-2xl font-bold">Imtihon topilmadi</h1><p className="mt-2 text-sm text-muted-foreground">{error}</p><Link href="/mock" className="mt-5 inline-flex rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Mocklarga qaytish</Link></div></main></div>
  return <div className="min-h-screen"><SiteHeader/><main className="container-shell py-10 sm:py-14">
    <Link href="/mock" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4"/> Mocklarga qaytish</Link>
    <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
      <section><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-primary">{exam.cefr_level}</span><span className="rounded-full border px-3 py-1 text-xs font-medium"><Clock3 className="mr-1 inline size-3.5"/>{exam.duration_minutes} daqiqa</span></div><h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">{exam.title}</h1><p className="mt-5 text-base leading-7 text-muted-foreground">{exam.description || 'Mock imtihon barcha 4 skill bo‘yicha o‘tkaziladi.'}</p>
        <div className="mt-8 grid gap-3 sm:grid-cols-2">{[['Reading','Qog‘oz asosida'],['Listening','Qog‘oz asosida'],['Writing','Qog‘oz asosida'],['Speaking','Kompyuter asosida']].map(([a,b])=><div key={a} className="rounded-xl border bg-card p-4"><CheckCircle2 className="size-5 text-primary"/><p className="mt-3 font-semibold">{a}</p><p className="mt-1 text-sm text-muted-foreground">{b}</p></div>)}</div>
      </section>
      <aside className="surface h-fit p-6"><h2 className="text-lg font-bold">Sana tanlang</h2><p className="mt-1 text-sm text-muted-foreground">Mavjud sessiyalardan birini tanlab ro‘yxatdan o‘ting.</p><div className="mt-5 space-y-3">{exam.sessions.length===0 ? <div className="rounded-lg bg-muted p-4 text-sm text-muted-foreground">Hozircha ochiq sana yo‘q.</div> : exam.sessions.map(s=><div key={s.id} className="rounded-xl border p-4"><div className="flex gap-3"><CalendarDays className="mt-0.5 size-5 text-primary"/><div className="min-w-0"><p className="font-semibold">{new Date(s.exam_date).toLocaleString('uz-UZ',{dateStyle:'medium',timeStyle:'short'})}</p><p className="mt-1 text-sm text-muted-foreground"><MapPin className="mr-1 inline size-3.5"/>{s.center_name || s.location_address}</p><p className="mt-1 text-xs text-muted-foreground">{s.available_seats==null?'Joylar cheklanmagan':s.is_full?'Joy qolmagan':`${s.available_seats} ta joy qoldi`}</p></div></div>{!s.is_full&&<Link href={`/mock/${exam.id}/register?session=${s.id}`} className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Ro‘yxatdan o‘tish <ArrowRight className="size-4"/></Link>}</div>)}</div><div className="mt-5 border-t pt-5"><div className="flex justify-between text-sm"><span className="text-muted-foreground">To‘lov</span><span className="font-bold">{exam.price>0?`${new Intl.NumberFormat('uz-UZ').format(exam.price)} UZS`:'Bepul'}</span></div></div></aside>
    </div></main></div>
}

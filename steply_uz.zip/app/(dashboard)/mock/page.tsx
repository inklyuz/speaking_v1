'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ArrowRight, CalendarDays, Clock3, MapPin, RefreshCw, Users } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { publicApi } from '@/lib/api/endpoints'
import type { MockExam } from '@/lib/api/types'

const money = new Intl.NumberFormat('uz-UZ')

export default function MockCatalogPage() {
  const [exams, setExams] = useState<MockExam[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  async function load() {
    setLoading(true); setError('')
    try { setExams(await publicApi.mockExams()) }
    catch (e) { setError(e instanceof Error ? e.message : 'Mock imtihonlarni yuklab bo‘lmadi.') }
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  return <div className="min-h-screen bg-background"><SiteHeader variant="public" />
    <main className="container-shell py-12 sm:py-16">
      <div className="max-w-3xl">
        <p className="text-sm font-semibold uppercase tracking-[.16em] text-primary">Mock Center</p>
        <h1 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">Haqiqiy imtihon formatida o‘zingizni sinang.</h1>
        <p className="mt-5 max-w-2xl text-base leading-7 text-muted-foreground">Qog‘ozdagi Reading, Listening, Writing va kompyuterdagi Speaking. Ochiq sanani tanlang va joyingizni oldindan band qiling.</p>
      </div>

      <div className="mt-10 flex items-center justify-between">
        <h2 className="text-xl font-bold">Ochiq mock imtihonlar</h2>
        <button onClick={load} className="inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium hover:bg-muted"><RefreshCw className="size-4"/> Yangilash</button>
      </div>

      {error && <div className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      {loading ? <div className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{[1,2,3].map(i=><div key={i} className="surface h-72 animate-pulse"/>)}</div> :
      exams.length === 0 ? <div className="surface mt-6 p-10 text-center text-sm text-muted-foreground">Hozircha ochiq mock imtihon yo‘q.</div> :
      <div className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{exams.map(exam => {
        const next = exam.sessions?.[0]
        return <article key={exam.id} className="surface overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md">
          <div className="h-36 bg-gradient-to-br from-primary/10 via-secondary to-background p-5">
            <div className="flex items-start justify-between gap-3"><span className="rounded-full bg-card px-2.5 py-1 text-xs font-semibold text-primary">{exam.cefr_level}</span><span className="rounded-full border bg-card/80 px-2.5 py-1 text-xs font-medium">{exam.duration_minutes} min</span></div>
            <h3 className="mt-8 line-clamp-2 text-xl font-bold">{exam.title}</h3>
          </div>
          <div className="p-5">
            <p className="line-clamp-2 min-h-12 text-sm leading-6 text-muted-foreground">{exam.description || 'To‘liq mock imtihon — barcha 4 skill.'}</p>
            {next && <div className="mt-4 space-y-2 text-xs text-muted-foreground"><div className="flex gap-2"><CalendarDays className="size-4 shrink-0"/><span>{new Date(next.exam_date).toLocaleString('uz-UZ', { dateStyle:'medium', timeStyle:'short' })}</span></div><div className="flex gap-2"><MapPin className="size-4 shrink-0"/><span>{next.center_name || next.location_address}</span></div><div className="flex gap-2"><Users className="size-4 shrink-0"/><span>{next.available_seats == null ? 'Joylar cheklanmagan' : `${next.available_seats} ta joy qoldi`}</span></div></div>}
            <div className="mt-5 flex items-center justify-between gap-3"><span className="font-bold">{exam.price > 0 ? `${money.format(exam.price)} UZS` : 'Bepul'}</span><Link href={`/mock/${exam.id}`} className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">Batafsil <ArrowRight className="size-4"/></Link></div>
          </div>
        </article>
      })}</div>}
    </main>
  </div>
}

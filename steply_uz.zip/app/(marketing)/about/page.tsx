import Link from 'next/link'
import { ArrowRight, BookOpen, Headphones, Mic2, PenLine, ShieldCheck, Star, Users } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader variant="public" />

      <main>
        <section className="border-b bg-card py-16">
          <div className="container-shell max-w-3xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">Biz haqimizda</p>
            <h1 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">
              Mock imtihon jarayonini soddalashtirmoqdamiz.
            </h1>
            <p className="mt-5 text-lg leading-8 text-muted-foreground">
              Mock Center — CEFR Multilevel imtihoniga tayyorgarlik ko'rish uchun onlayn platforma. 
              Mock testlar, speaking sessiyasi va natijalarni bir joyda jamlashdan iborat.
            </p>
            <Link
              href="/mock"
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground"
            >
              Mock imtihonni boshlash <ArrowRight className="size-4" />
            </Link>
          </div>
        </section>

        <section className="container-shell py-16">
          <div className="grid gap-8 sm:grid-cols-3">
            {[
              { icon: Users, title: 'Talabgor uchun', desc: 'Ro\'yxatdan o\'tish, mock test topshirish, speaking imtihoniga kirish va natijani ko\'rish — barchasi bir platformada.' },
              { icon: ShieldCheck, title: 'Xavfsiz va ishonchli', desc: 'Ma\'lumotlaringiz xavfsiz saqlanadi. Audio javoblar faqat vakolatli baholovchilarga ko\'rinadi.' },
              { icon: Star, title: 'CEFR standartida', desc: 'Barcha imtihon materiallari va baholash Yevropa tillarni bilish darajalari çerçevesi (CEFR) ga asoslangan.' },
            ].map((item) => (
              <div key={item.title} className="surface p-6">
                <div className="flex size-10 items-center justify-center rounded-lg bg-secondary text-primary">
                  <item.icon className="size-5" />
                </div>
                <h3 className="mt-5 font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="border-t bg-card py-16">
          <div className="container-shell">
            <h2 className="text-2xl font-bold tracking-tight">Platforma imkoniyatlari</h2>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: BookOpen, name: 'Reading', desc: 'Mock testda reading bo\'limini topshiring.' },
                { icon: Headphones, name: 'Listening', desc: 'Listening savollariga vaqt chegarasida javob bering.' },
                { icon: PenLine, name: 'Writing', desc: 'Writing topshiriqlarini bajarib natijangizni ko\'ring.' },
                { icon: Mic2, name: 'Speaking', desc: 'Kompyuter asosidagi speaking sessiyasini o\'ting.', accent: true },
              ].map((c) => (
                <div key={c.name} className={`rounded-xl border p-6 ${c.accent ? 'border-primary/30 bg-primary/5' : 'bg-background'}`}>
                  <div className={`flex size-10 items-center justify-center rounded-lg ${c.accent ? 'bg-primary text-primary-foreground' : 'bg-muted text-primary'}`}>
                    <c.icon className="size-5" />
                  </div>
                  <p className="mt-4 font-semibold">{c.name}</p>
                  <p className="mt-1 text-sm leading-6 text-muted-foreground">{c.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="container-shell py-16">
          <div className="surface flex flex-col items-center gap-4 p-10 text-center">
            <h2 className="text-2xl font-bold">Boshlashga tayyormisiz?</h2>
            <p className="max-w-md text-muted-foreground">
              Bepul ro'yxatdan o'ting va mock imtihon bilan CEFR darajangizni aniqlang.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link href="/register" className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground">
                Ro'yxatdan o'tish <ArrowRight className="size-4" />
              </Link>
              <Link href="/exams" className="rounded-lg border px-5 py-3 text-sm font-semibold hover:bg-muted">
                Imtihon haqida
              </Link>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

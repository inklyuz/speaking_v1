import { SiteFooter } from '@/components/site-footer'

// SiteHeader useAuth (Steply auth-context) orqali ishlaydi, u faqat mijoz tomonida mavjud
// bo'lgani uchun bu guruh sahifalari build vaqtida statik emas, dinamik render qilinadi.
export const dynamic = 'force-dynamic'

export default function MarketingLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      {children}
      <SiteFooter />
    </>
  )
}

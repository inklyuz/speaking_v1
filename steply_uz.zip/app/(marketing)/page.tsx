import PlatformHomeUz from '@/components/platform-home-uz'

export default function Page() {
  return <PlatformHomeUz />
}
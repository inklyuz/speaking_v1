'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { AdminSidebar } from '@/components/admin-sidebar'
import { AdminTopbar } from '@/components/admin-topbar'
import { useAuth } from '@/lib/auth/auth-context'

// useAuth (Steply auth-context) faqat mijoz tomonida ishlaydi va build vaqtida
// statik prerender qilinsa xatolik beradi — shuning uchun bu bo'lim doim dinamik render qilinadi.
export const dynamic = 'force-dynamic'

const ALLOWED_ROLES = ['admin', 'speaking_evaluator']

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { user, isLoading, isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (isLoading) return
    if (!isAuthenticated) {
      router.replace('/login?next=/admin')
      return
    }
    if (user && !ALLOWED_ROLES.includes(user.global_role)) {
      router.replace('/dashboard')
    }
  }, [isLoading, isAuthenticated, user, router])

  if (isLoading || !isAuthenticated || (user && !ALLOWED_ROLES.includes(user.global_role))) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground">Yuklanmoqda...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background lg:flex">
      <AdminSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex min-h-screen flex-1 flex-col">
        <AdminTopbar onMenuClick={() => setSidebarOpen(true)} />
        <main className="flex-1">{children}</main>
      </div>
    </div>
  )
}

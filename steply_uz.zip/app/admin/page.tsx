'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { BarChart3, BookOpen, Calendar, Check, ChevronDown, ChevronUp, Download, Headphones, Mic2, Plus, ShieldAlert, Trash2, Users, PenLine } from 'lucide-react'
import { adminApi, listeningApi, mockExamsApi, readingApi, speakingApi, writingApi } from '@/lib/api/endpoints'
import { authenticatedDownload } from '@/lib/api/download'
import type { AdminStatistics, ListeningTest, MockExam, ReadingTest, SpeakingTestSummary, WritingExam } from '@/lib/api/types'
import { useAuth } from '@/lib/auth/auth-context'
import { ApiRequestError } from '@/lib/api/client'

const CEFR_LEVELS = ['Multilevel', 'B1', 'B2', 'C1']
const EMPTY_FORM = { title: '', price: 0, cefr_level: 'B1', duration_minutes: 180, description: '', reading_id: '', listening_id: '', writing_id: '', speaking_id: '', is_active: true }

type SkillKey = 'reading_id' | 'listening_id' | 'writing_id' | 'speaking_id'

type SkillOption = { id: string; title: string; level: string }

const MOCK_JSON = `{
  "title": "Mock B1 #1",
  "cefr_level": "B1",
  "duration_minutes": 180,
  "reading_id": "READ-xxxxxxxx",
  "listening_id": "LIST-xxxxxxxx",
  "writing_id": "WRIT-xxxxxxxx",
  "speaking_id": "SPEAK-xxxxxxxx"
}`

function asArray<T>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[]
  if (value && typeof value === 'object') {
    const v = value as Record<string, unknown>
    for (const key of ['items', 'data', 'results', 'tests', 'exams']) if (Array.isArray(v[key])) return v[key] as T[]
  }
  return []
}

export default function AdminPage() {
  const { user, isLoading } = useAuth()
  const [stats, setStats] = useState<AdminStatistics | null>(null)
  const [exams, setExams] = useState<MockExam[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [loadingTests, setLoadingTests] = useState(false)
  const [advanced, setAdvanced] = useState(false)
  const [showJson, setShowJson] = useState(false)
  const [busy, setBusy] = useState<Record<string, boolean>>({})
  const [tests, setTests] = useState<Record<SkillKey, SkillOption[]>>({ reading_id: [], listening_id: [], writing_id: [], speaking_id: [] })

  const isAdmin = user?.global_role === 'admin'

  useEffect(() => {
    if (!isAdmin) return
    adminApi.statistics().then(setStats).catch(() => setError('Statistikani yuklab bo‘lmadi'))
    mockExamsApi.adminList().then(x => setExams(asArray<MockExam>(x))).catch(() => setExams([]))
    loadSkillTests()
  }, [isAdmin])

  async function loadSkillTests() {
    setLoadingTests(true); setError(null)
    try {
      const [r, l, w, s] = await Promise.all([readingApi.getAll(), listeningApi.getAll(), writingApi.getAll(), speakingApi.listTests()])
      const reading = asArray<ReadingTest>(r).map(x => ({ id: x.id, title: x.title, level: x.cefr_level || '—' }))
      const listening = asArray<ListeningTest>(l).map(x => ({ id: x.id, title: x.title, level: x.level || '—' }))
      const writing = asArray<WritingExam>(w).map(x => ({ id: x.id, title: x.title, level: x.cefr_level || '—' }))
      const speaking = asArray<SpeakingTestSummary>(s).map(x => ({ id: x.id, title: x.title, level: 'Speaking' }))
      setTests({ reading_id: reading, listening_id: listening, writing_id: writing, speaking_id: speaking })
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : 'Skill testlarini yuklab bo‘lmadi')
    } finally { setLoadingTests(false) }
  }

  function setF<K extends keyof typeof EMPTY_FORM>(key: K, value: (typeof EMPTY_FORM)[K]) { setForm(f => ({ ...f, [key]: value })) }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault(); setSaving(true); setError(null)
    const missing = (Object.keys(tests) as SkillKey[]).filter(k => !form[k].trim())
    if (missing.length) { setError('Mock yaratish uchun Reading, Listening, Writing va Speaking testlarining barchasini tanlang.'); setSaving(false); return }
    try {
      const payload = { title: form.title.trim(), price: Number(form.price), cefr_level: form.cefr_level, duration_minutes: Number(form.duration_minutes), is_active: form.is_active, description: form.description.trim() || null, reading_id: form.reading_id, listening_id: form.listening_id, writing_id: form.writing_id, speaking_id: form.speaking_id }
      await mockExamsApi.create(payload)
      setExams(asArray<MockExam>(await mockExamsApi.adminList())); setForm(EMPTY_FORM); setAdvanced(false)
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : 'Mock yaratishda xatolik')
    } finally { setSaving(false) }
  }

  async function handleRemove(id: string) {
    if (!confirm(`"${id}" mock imtihonini o‘chirishni tasdiqlaysizmi?`)) return
    setBusy(b => ({ ...b, [id]: true })); setError(null)
    try { await mockExamsApi.remove(id); setExams(prev => prev?.filter(x => x.id !== id) ?? null) }
    catch (err) { setError(err instanceof ApiRequestError ? err.message : 'O‘chirishda xatolik') }
    finally { setBusy(b => ({ ...b, [id]: false })) }
  }

  async function download(url: string, filename: string) {
    setBusy(b => ({ ...b, [filename]: true })); await authenticatedDownload(url, { filename, onError: setError }); setBusy(b => ({ ...b, [filename]: false }))
  }

  if (isLoading) return <div className="flex min-h-svh items-center justify-center text-sm text-muted-foreground">Yuklanmoqda...</div>
  if (!isAdmin) return <div className="flex min-h-svh flex-col items-center justify-center gap-3 px-4 text-center"><ShieldAlert className="size-8 text-muted-foreground" /><p className="font-semibold">Bu bo‘limga faqat administratorlar kira oladi.</p><Link href="/dashboard" className="text-sm font-semibold text-primary hover:underline">Kabinetga qaytish</Link></div>

  const skillMeta: Array<{ key: SkillKey; label: string; icon: typeof BookOpen }> = [
    { key: 'reading_id', label: 'Reading', icon: BookOpen }, { key: 'listening_id', label: 'Listening', icon: Headphones }, { key: 'writing_id', label: 'Writing', icon: PenLine }, { key: 'speaking_id', label: 'Speaking', icon: Mic2 },
  ]

  return <main className="container-shell py-10 space-y-8">
    <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div><p className="text-sm font-semibold text-primary">Admin</p><h1 className="mt-1 text-2xl font-bold tracking-tight">Mock Center</h1><p className="mt-1 text-sm text-muted-foreground">4 ta skill testini bitta mock imtihonga biriktiring.</p></div>
      <button type="button" onClick={() => setShowJson(v => !v)} className="inline-flex w-fit items-center gap-2 rounded-lg border bg-card px-3 py-2 text-sm font-semibold hover:bg-muted"><ChevronDown className="size-4" /> Namuna JSON</button>
    </header>

    {showJson && <div className="surface overflow-hidden"><pre className="overflow-x-auto p-5 text-xs leading-6 text-muted-foreground">{MOCK_JSON}</pre></div>}
    {error && <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

    <section className="grid gap-4 sm:grid-cols-3">
      {[['Jami foydalanuvchilar', stats?.total_users, Users], ['Topshirilgan imtihonlar', stats?.total_exams_taken, BarChart3], ['Bugungi foydalanuvchilar', stats?.users_today, Users]].map(([label, value, Icon]) => <div className="surface p-5" key={String(label)}><div className="flex size-9 items-center justify-center rounded-lg bg-secondary text-primary"><Icon className="size-4" /></div><p className="mt-4 text-2xl font-bold">{value ?? '—'}</p><p className="mt-1 text-sm text-muted-foreground">{label}</p></div>)}
    </section>

    <section className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
      <div className="surface p-6">
        <div className="flex items-start justify-between gap-3"><div><h2 className="font-bold">Yangi mock yaratish</h2><p className="mt-1 text-xs text-muted-foreground">Har bir skill uchun tayyor testni tanlang.</p></div><span className="rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-primary">4 / 4</span></div>
        <form onSubmit={handleCreate} className="mt-6 space-y-4">
          <label className="block"><span className="label-xs">Sarlavha *</span><input required minLength={3} value={form.title} onChange={e => setF('title', e.target.value)} className="field" placeholder="Mock B1 #1" /></label>
          <div className="grid grid-cols-2 gap-3"><label className="block"><span className="label-xs">CEFR *</span><select value={form.cefr_level} onChange={e => setF('cefr_level', e.target.value)} className="field">{CEFR_LEVELS.map(x => <option key={x}>{x}</option>)}</select></label><label className="block"><span className="label-xs">Narx (so‘m)</span><input type="number" min={0} value={form.price} onChange={e => setF('price', Number(e.target.value))} className="field" /></label></div>
          <label className="block"><span className="label-xs">Davomiyligi (daqiqa)</span><input type="number" min={30} max={360} value={form.duration_minutes} onChange={e => setF('duration_minutes', Number(e.target.value))} className="field" /></label>
          <div className="space-y-3">
            {skillMeta.map(({ key, label, icon: Icon }) => <label key={key} className="block"><span className="label-xs flex items-center gap-1.5"><Icon className="size-3.5" />{label} test *</span><select required value={form[key]} onChange={e => setF(key, e.target.value)} className="field" disabled={loadingTests}><option value="">{loadingTests ? 'Testlar yuklanmoqda...' : `${label} testini tanlang`}</option>{tests[key].map(t => <option value={t.id} key={t.id}>{t.id} — {t.title} [{t.level}]</option>)}</select></label>)}
          </div>
          <button type="button" onClick={() => setAdvanced(v => !v)} className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground">{advanced ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />} Qo‘shimcha</button>
          {advanced && <div className="space-y-3 rounded-xl border bg-muted/30 p-4"><label className="block"><span className="label-xs">Tavsif</span><textarea rows={3} value={form.description} onChange={e => setF('description', e.target.value)} className="field resize-none" placeholder="Imtihon haqida..." /></label><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.is_active} onChange={e => setF('is_active', e.target.checked)} /> Foydalanuvchilarga ko‘rinsin</label></div>}
          <button type="submit" disabled={saving || loadingTests} className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-60"><Plus className="size-4" />{saving ? 'Yaratilmoqda...' : 'Mock yaratish'}</button>
        </form>
      </div>

      <div className="surface p-6"><div className="flex items-center justify-between gap-3"><div><h2 className="font-bold">Mock imtihonlar</h2><p className="mt-1 text-xs text-muted-foreground">Biriktirilgan 4 ta test shu yerda ko‘rinadi.</p></div><button onClick={() => mockExamsApi.adminList().then(x => setExams(asArray<MockExam>(x)))} className="text-xs font-semibold text-primary hover:underline">Yangilash</button></div>
        <div className="mt-5 space-y-3">{exams === null ? <p className="text-sm text-muted-foreground">Yuklanmoqda...</p> : exams.length === 0 ? <p className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">Hali mock yaratilmagan.</p> : exams.map(exam => <div key={exam.id} className="rounded-xl border p-4"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="font-semibold truncate">{exam.title}</p><p className="mt-1 text-xs text-muted-foreground">{exam.id} · {exam.cefr_level} · {exam.duration_minutes} daqiqa</p></div><button onClick={() => handleRemove(exam.id)} disabled={!!busy[exam.id]} className="rounded-lg p-1.5 text-red-500 hover:bg-red-50"><Trash2 className="size-4" /></button></div><div className="mt-3 grid grid-cols-2 gap-2">{skillMeta.map(({ key, label }) => <div key={key} className="rounded-lg bg-muted/50 px-3 py-2"><p className="text-[10px] font-semibold uppercase text-muted-foreground">{label}</p><p className="mt-0.5 truncate text-xs font-medium">{exam[key] || 'Biriktirilmagan'}</p></div>)}</div><div className="mt-3 flex flex-wrap gap-2">{([['R', mockExamsApi.readingPaperUrl(exam.id), `${exam.id}-reading.pdf`], ['L', mockExamsApi.listeningPaperUrl(exam.id), `${exam.id}-listening.pdf`], ['W', mockExamsApi.writingPaperUrl(exam.id), `${exam.id}-writing.pdf`]] as const).map(([label, url, file]) => <button key={label} onClick={() => download(url, file)} className="rounded-lg border px-2.5 py-1 text-xs font-bold hover:bg-muted">{busy[file] ? '…' : label}</button>)}</div></div>)}</div>
      </div>
    </section>

    <section className="flex flex-wrap gap-2">{[["/admin/reading", 'Reading', BookOpen], ["/admin/listening", 'Listening', Headphones], ["/admin/writing", 'Writing', PenLine], ["/admin/speaking/questions", 'Speaking', Mic2], ["/admin/mock", 'Sessiyalar', Calendar]].map(([href, label, Icon]) => <Link key={String(href)} href={String(href)} className="inline-flex items-center gap-2 rounded-lg border bg-card px-3 py-2 text-sm font-semibold hover:bg-muted"><Icon className="size-4" />{label}</Link>)}</section>
    <button onClick={() => download(adminApi.exportUsersUrl(), 'users_export.xlsx')} className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline"><Download className="size-4" />Foydalanuvchilarni Excel'da yuklab olish</button>
  </main>
}

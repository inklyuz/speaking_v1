'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ShieldAlert } from 'lucide-react'
import { speakingApi } from '@/lib/api/endpoints'
import type { SpeakingSubmission } from '@/lib/api/types'
import { useAuth } from '@/lib/auth/auth-context'

// Backend /speaking/pending va /speaking/{id}/result endpointlari ADMIN VA
// SPEAKING_EVALUATOR rollariga ruxsat beradi (require_role(SPEAKING_EVALUATOR, ADMIN)) —
// bu sahifa ilgari faqat "admin"ni tekshirar edi, shu sabab baholovchi (evaluator)
// hisobi bilan kirgan xodim bu bo'limni umuman ko'ra olmasdi.
const ALLOWED_ROLES = ['admin', 'speaking_evaluator']

export default function Page() {
  const { user, isLoading } = useAuth()
  const [submissions, setSubmissions] = useState<SpeakingSubmission[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  const canGrade = !!user && ALLOWED_ROLES.includes(user.global_role)

  useEffect(() => {
    if (!canGrade) return
    speakingApi.pendingSubmissions()
      .then(setSubmissions)
      .catch(() => {
        setSubmissions([])
        setError("Speaking topshiriqlarini yuklab bo'lmadi.")
      })
  }, [canGrade])

  if (isLoading) return (
    <div className="flex min-h-svh items-center justify-center text-sm text-muted-foreground">Yuklanmoqda...</div>
  )

  if (!canGrade) return (
    <div className="flex min-h-svh flex-col items-center justify-center gap-3 px-4 text-center">
      <ShieldAlert className="size-8 text-muted-foreground" />
      <p className="font-semibold">Bu bo'limga faqat administrator yoki baholovchi kira oladi.</p>
      <Link href="/dashboard" className="text-sm font-semibold text-primary hover:underline">Kabinetga qaytish</Link>
    </div>
  )

  return (
    <div className="container-shell py-10">
      <p className="text-sm font-semibold uppercase tracking-wider text-primary">Speaking</p>
      <h1 className="mt-2 text-3xl font-bold tracking-tight">Talabgorlar javoblari</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Talabgor speaking imtihonini topshirgach, uning audio javoblari shu ro'yxatda paydo bo'ladi.
      </p>

      {error && (
        <p className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p>
      )}

      {submissions === null && (
        <div className="mt-8 space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-14 animate-pulse rounded-xl border bg-muted" />
          ))}
        </div>
      )}

      {submissions?.length === 0 && !error && (
        <div className="surface mt-8 p-10 text-center text-sm text-muted-foreground">
          Hozircha baholanishi kutilayotgan speaking topshiriqlari yo'q.
        </div>
      )}

      {submissions && submissions.length > 0 && (
        <div className="surface mt-8 overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-muted/50 text-xs text-muted-foreground">
              <tr>
                <th className="px-5 py-3 font-medium">Talabgor</th>
                <th className="px-5 py-3 font-medium">Test</th>
                <th className="px-5 py-3 font-medium">Topshirilgan vaqt</th>
                <th className="px-5 py-3 font-medium">Holati</th>
                <th className="px-5 py-3 font-medium" />
              </tr>
            </thead>
            <tbody className="divide-y">
              {submissions.map((sub) => (
                <tr key={sub.id} className="hover:bg-muted/30">
                  <td className="px-5 py-3">
                    <p className="font-medium">{sub.full_name || `Foydalanuvchi #${sub.user_id}`}</p>
                    {sub.student_id && <p className="mt-0.5 font-mono text-xs text-primary">{sub.student_id}</p>}
                  </td>
                  <td className="px-5 py-3 text-muted-foreground">{sub.speaking_test_id}</td>
                  <td className="px-5 py-3 text-muted-foreground">
                    {new Date(sub.created_at).toLocaleString('uz-UZ')}
                  </td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                      sub.status === 'graded'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}>
                      {sub.status === 'graded' ? 'Baholandi' : 'Kutilmoqda'}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <Link
                      href={`/admin/speaking/assessments/${sub.id}`}
                      className="text-sm font-semibold text-primary hover:underline"
                    >
                      Baholash →
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

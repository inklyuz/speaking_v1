'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { authApi } from '@/lib/api/endpoints'
import { ApiRequestError } from '@/lib/api/client'
import { homeUrlForRole } from '@/lib/auth/auth-context'
import { Button } from '@/components/ui/button'

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [phone, setPhone] = useState('+998')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      const res = await authApi.phoneLogin(phone.trim(), password)

      if (res.status === 'need_registration') {
        router.push(`/register?phone=${encodeURIComponent(phone.trim())}`)
        return
      }
      if (res.status !== 'success') {
        setError(res.message || 'Kirishda xatolik yuz berdi')
        return
      }

      // "next" query bo'lsa avval o'shanga, aks holda rolega qarab
      // (admin/speaking_evaluator -> /admin, oddiy foydalanuvchi -> /dashboard).
      const next = searchParams.get('next')
      if (next) {
        router.push(next)
        return
      }
      const me = await authApi.me().catch(() => null)
      router.push(homeUrlForRole(me?.global_role))
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : "Kirishda xatolik yuz berdi")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="flex min-h-svh items-center justify-center bg-[#0B1220] px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <Link href="/" className="text-2xl font-bold tracking-tight text-white">
            Steply<span className="text-emerald-400">.</span>
          </Link>
          <p className="mt-2 text-sm text-slate-400">Hisobingizga kiring</p>
        </div>

        <form onSubmit={onSubmit} className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 shadow-xl backdrop-blur">
          <div className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">Telefon raqam</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+998901234567"
                required
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-500 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
              />
            </div>
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label className="block text-sm font-medium text-slate-300">Parol</label>
                <Link href="/forgot-password" className="text-xs text-emerald-400 hover:underline">
                  Parolni unutdingizmi?
                </Link>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-500 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
              />
            </div>
          </div>

          {error && (
            <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>
          )}

          <Button type="submit" disabled={loading} className="mt-6 h-11 w-full rounded-lg bg-emerald-500 text-sm font-semibold text-black hover:bg-emerald-400">
            {loading ? 'Kirilmoqda...' : 'Kirish'}
          </Button>

          <p className="mt-5 text-center text-sm text-slate-400">
            Hisobingiz yo'qmi?{' '}
            <Link href="/register" className="font-medium text-emerald-400 hover:underline">
              Ro'yxatdan o'tish
            </Link>
          </p>
        </form>
      </div>
    </main>
  )
}

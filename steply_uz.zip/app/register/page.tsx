'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { authApi } from '@/lib/api/endpoints'
import { ApiRequestError } from '@/lib/api/client'
import { homeUrlForRole } from '@/lib/auth/auth-context'
import { Button } from '@/components/ui/button'

type Step = 'form' | 'verify'

export default function RegisterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [step, setStep] = useState<Step>('form')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState(searchParams.get('phone') || '+998')
  const [password, setPassword] = useState('')
  const [birthDate, setBirthDate] = useState('')
  const [gender, setGender] = useState<'male' | 'female'>('male')
  const [code, setCode] = useState('')

  async function onRegister(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await authApi.register({
        phone: phone.trim(),
        password,
        full_name: fullName.trim(),
        birth_date: birthDate,
        gender,
        channel: 'sms',
      })
      setStep('verify')
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : "Ro'yxatdan o'tishda xatolik")
    } finally {
      setLoading(false)
    }
  }

  async function onVerify(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await authApi.registerVerify({ phone: phone.trim(), code: code.trim() })
      const next = searchParams.get('next')
      if (next) { router.push(next); return }
      const me = await authApi.me().catch(() => null)
      router.push(homeUrlForRole(me?.global_role))
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : 'Kod tasdiqlanmadi')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="flex min-h-svh items-center justify-center bg-[#0B1220] px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <Link href="/" className="text-2xl font-bold tracking-tight text-white">
            Steply<span className="text-emerald-400">.</span>
          </Link>
          <p className="mt-2 text-sm text-slate-400">
            {step === 'form' ? "Yangi hisob yarating" : 'Telefon raqamni tasdiqlang'}
          </p>
        </div>

        {step === 'form' ? (
          <form onSubmit={onRegister} className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 shadow-xl backdrop-blur">
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-slate-300">To'liq ism</label>
                <input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  minLength={2}
                  placeholder="Ali Valiyev"
                  className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-500 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-slate-300">Telefon raqam</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  placeholder="+998901234567"
                  className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-500 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-slate-300">Tug'ilgan sana</label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    required
                    className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-slate-300">Jins</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as 'male' | 'female')}
                    className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
                  >
                    <option className="bg-[#0B1220]" value="male">Erkak</option>
                    <option className="bg-[#0B1220]" value="female">Ayol</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-slate-300">Parol</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  placeholder="Kamida 6 ta belgi"
                  className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-500 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
                />
              </div>
            </div>

            {error && (
              <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>
            )}

            <Button type="submit" disabled={loading} className="mt-6 h-11 w-full rounded-lg bg-emerald-500 text-sm font-semibold text-black hover:bg-emerald-400">
              {loading ? 'Yuborilmoqda...' : 'Davom etish'}
            </Button>

            <p className="mt-5 text-center text-sm text-slate-400">
              Hisobingiz bormi?{' '}
              <Link href="/login" className="font-medium text-emerald-400 hover:underline">
                Kirish
              </Link>
            </p>
          </form>
        ) : (
          <form onSubmit={onVerify} className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 shadow-xl backdrop-blur">
            <p className="mb-4 text-sm text-slate-400">
              <span className="text-white">{phone}</span> raqamiga yuborilgan 6 xonali kodni kiriting.
            </p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              required
              maxLength={6}
              inputMode="numeric"
              placeholder="123456"
              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-center text-lg tracking-[0.5em] text-white outline-none focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
            />

            {error && (
              <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>
            )}

            <Button type="submit" disabled={loading} className="mt-6 h-11 w-full rounded-lg bg-emerald-500 text-sm font-semibold text-black hover:bg-emerald-400">
              {loading ? 'Tasdiqlanmoqda...' : 'Tasdiqlash'}
            </Button>
            <button
              type="button"
              onClick={() => setStep('form')}
              className="mt-3 w-full text-center text-sm text-slate-400 hover:text-slate-300"
            >
              ← Orqaga qaytish
            </button>
          </form>
        )}
      </div>
    </main>
  )
}

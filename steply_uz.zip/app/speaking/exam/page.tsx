import { SpeakingSession } from '@/components/speaking-session'
export default function Page() { return <SpeakingSession /> }

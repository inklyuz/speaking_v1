'use client'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { Mic, ShieldCheck } from 'lucide-react'
import { speakingApi } from '@/lib/api/endpoints'
import { useAuth } from '@/lib/auth/auth-context'
export default function Page(){
 const {isAuthenticated,isLoading}=useAuth(); const [ok,setOk]=useState(false); const [error,setError]=useState(''); const [checking,setChecking]=useState(false)
 useEffect(()=>{if(!isAuthenticated)return; speakingApi.myAssignedTest().then(()=>setOk(true)).catch(e=>setError(e instanceof Error?e.message:'Faol Speaking sessiya topilmadi.'))},[isAuthenticated])
 async function testMic(){setChecking(true);setError('');try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});stream.getTracks().forEach(t=>t.stop());setOk(true)}catch{setError('Mikrofonga ruxsat berilmadi.')}}
 if(isLoading)return <div className="flex min-h-svh items-center justify-center">Yuklanmoqda...</div>
 return <main className="container-shell min-h-screen py-16"><div className="surface mx-auto max-w-xl p-8 text-center"><ShieldCheck className="mx-auto size-12 text-primary"/><h1 className="mt-5 text-2xl font-bold">Speaking pre-check</h1><p className="mt-2 text-sm text-muted-foreground">Sessiya va mikrofonni imtihondan oldin tekshiring.</p>{error&&<p className="mt-5 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</p>}<button onClick={testMic} disabled={!isAuthenticated||checking} className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-50"><Mic className="size-4"/>{checking?'Tekshirilmoqda...':'Mikrofonni tekshirish'}</button>{ok&&<Link href="/speaking/exam" className="ml-2 inline-flex rounded-lg border px-5 py-3 text-sm font-semibold">Speakingga kirish</Link>}</div></main>
}

'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  BarChart3, BookOpen, Calendar, CheckCircle2, ChevronRight,
  Headphones, LayoutDashboard, Mic2, Users, X, FileText, ScanLine,
} from 'lucide-react'
import { useAuth } from '@/lib/auth/auth-context'

const NAV_ADMIN = [
  {
    label: 'Asosiy',
    items: [
      { href: '/admin', icon: LayoutDashboard, label: 'Boshqaruv paneli', exact: true },
      { href: '/admin/mock', icon: Calendar, label: 'Sessiyalar' },
      { href: '/admin/applications', icon: Users, label: "Ro'yxatlar" },
      { href: '/admin/check-in', icon: CheckCircle2, label: 'Check-in' },
    ],
  },
  {
    label: 'Testlar',
    items: [
      { href: '/admin/reading', icon: BookOpen, label: 'Reading' },
      { href: '/admin/listening', icon: Headphones, label: 'Listening' },
      { href: '/admin/speaking/questions', icon: Mic2, label: 'Speaking' },
      { href: '/admin/speaking/assessments', icon: BarChart3, label: 'Baholash' },
      { href: '/admin/writing', icon: FileText, label: 'Writing baholash' },
      { href: '/admin/omr', icon: ScanLine, label: 'OMR' },
      { href: '/admin/finalize', icon: CheckCircle2, label: 'Finalizatsiya' },
    ],
  },
]

// speaking_evaluator hisobi backendda faqat /speaking/pending va
// /speaking/{id}/result endpointlariga ruxsatga ega — shu uchun menyusi
// ham faqat shu bo'limni ko'rsatadi (boshqa admin havolalarini bossa 403
// olardi, endi umuman ko'rsatilmaydi).
const NAV_EVALUATOR = [
  {
    label: 'Speaking',
    items: [
      { href: '/admin/speaking/assessments', icon: BarChart3, label: 'Baholash', exact: false },
    ],
  },
]

interface Props {
  open: boolean
  onClose: () => void
}

export function AdminSidebar({ open, onClose }: Props) {
  const pathname = usePathname()
  const { user } = useAuth()
  const NAV = user?.global_role === 'speaking_evaluator' ? NAV_EVALUATOR : NAV_ADMIN

  function isActive(href: string, exact?: boolean) {
    return exact ? pathname === href : pathname.startsWith(href)
  }

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar panel */}
      <aside
        className={`
          fixed left-0 top-0 z-50 flex h-screen w-64 flex-col border-r bg-card
          transition-transform duration-200
          ${open ? 'translate-x-0' : '-translate-x-full'}
          lg:sticky lg:top-0 lg:translate-x-0 lg:z-auto
        `}
      >
        {/* Logo */}
        <div className="flex h-16 items-center justify-between border-b px-5">
          <Link href="/admin" className="font-semibold tracking-tight text-sm">
            Steply<span className="text-primary">.</span>{' '}
            <span className="font-normal text-muted-foreground">Admin</span>
          </Link>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground lg:hidden"
          >
            <X className="size-4" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {NAV.map(group => (
            <div key={group.label}>
              <p className="mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/60">
                {group.label}
              </p>
              <ul className="space-y-0.5">
                {group.items.map(item => {
                  const active = isActive(item.href, item.exact)
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        onClick={onClose}
                        className={`
                          flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors
                          ${active
                            ? 'bg-primary/8 text-primary'
                            : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                          }
                        `}
                      >
                        <item.icon className={`size-4 shrink-0 ${active ? 'text-primary' : ''}`} />
                        <span className="flex-1">{item.label}</span>
                        {active && <ChevronRight className="size-3 text-primary/60" />}
                      </Link>
                    </li>
                  )
                })}
              </ul>
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div className="border-t px-3 py-3">
          <Link
            href="/dashboard"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            ← Saytga qaytish
          </Link>
        </div>
      </aside>
    </>
  )
}

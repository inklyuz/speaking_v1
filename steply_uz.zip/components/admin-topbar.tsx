'use client'

import { usePathname } from 'next/navigation'
import { Bell, Menu, Search } from 'lucide-react'

const ROUTE_LABELS: Record<string, string> = {
  '/admin': 'Boshqaruv paneli',
  '/admin/mock': 'Sessiyalar',
  '/admin/reading': 'Reading (qog\u2019oz asosida)',
  '/admin/listening': 'Listening (qog\u2019oz asosida)',
  '/admin/writing': 'Writing baholash (qog\u2019oz asosida)',
  '/admin/omr': 'OMR — javob varag\u2019ini skanerlash',
  '/admin/check-in': 'Check-in',
  '/admin/finalize': 'Finalizatsiya',
  '/admin/speaking/questions': 'Speaking testlari',
  '/admin/speaking/assessments': 'Baholash',
  '/admin/applications': "Ro'yxatlar",
}

function getPageTitle(pathname: string): string {
  if (ROUTE_LABELS[pathname]) return ROUTE_LABELS[pathname]
  if (pathname.startsWith('/admin/reading/')) return 'Reading — Tahrirlash'
  if (pathname.startsWith('/admin/listening/')) return 'Listening — Tahrirlash'
  if (pathname.startsWith('/admin/writing/')) return 'Writing — Baholash'
  if (pathname.startsWith('/admin/speaking/assessments/')) return 'Baholash — Batafsil'
  return 'Admin'
}

interface Props {
  onMenuClick: () => void
}

export function AdminTopbar({ onMenuClick }: Props) {
  const pathname = usePathname()
  const title = getPageTitle(pathname)

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-card/80 backdrop-blur-sm px-5">
      {/* Mobile menu button */}
      <button
        onClick={onMenuClick}
        className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground lg:hidden"
        aria-label="Menyuni ochish"
      >
        <Menu className="size-5" />
      </button>

      {/* Page title */}
      <h1 className="flex-1 text-sm font-semibold text-foreground truncate">{title}</h1>

      {/* Right actions */}
      <div className="flex items-center gap-1">
        <button className="rounded-md p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
          <Search className="size-4" />
        </button>
        <button className="rounded-md p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
          <Bell className="size-4" />
        </button>
        {/* Avatar placeholder */}
        <div className="ml-1 flex size-8 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">
          A
        </div>
      </div>
    </header>
  )
}

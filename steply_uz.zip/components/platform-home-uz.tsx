'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import {
  ArrowRight, BookOpen, CalendarDays, Check, CheckCircle2, ChevronDown, Clock3,
  Headphones, LockKeyhole, Mic2, PenLine, Play, ShieldCheck, Sparkles, Star, Users,
} from 'lucide-react'
import { publicApi } from '@/lib/api/endpoints'
import type { MockExam } from '@/lib/api/types'
import { useAuth } from '@/lib/auth/auth-context'
import { SiteHeader } from '@/components/site-header'

const skillCards = [
  { icon: BookOpen, title: 'Reading', tag: 'Qog\'oz asosida', copy: 'Matnni tushunish, kontekst va ma\'noni aniqlash ko\'nikmalaringizni sinab ko\'ring.' },
  { icon: Headphones, title: 'Listening', tag: 'Qog\'oz asosida', copy: 'Tinglab tushunish qobiliyatingizni haqiqiy imtihon formatida baholang.' },
  { icon: PenLine, title: 'Writing', tag: 'Qog\'oz asosida', copy: 'Fikrni aniq va tuzilgan tarzda yozma bayon qilishni mashq qiling.' },
  { icon: Mic2, title: 'Speaking', tag: 'Kompyuter asosida', copy: 'Ovozli javoblar yozib olinadigan, qadamma-qadam boshqariladigan sessiya.', accent: true },
]

const steps = [
  { title: 'Ro\'yxatdan o\'ting', desc: 'Telefon raqamingiz orqali bir necha daqiqada hisob oching.' },
  { title: 'Mock imtihonni tanlang', desc: 'CEFR darajangizga mos mock-testni sotib oling yoki bepul demo bilan boshlang.' },
  { title: 'Barcha bo\'limlarni topshiring', desc: 'Reading, Listening, Writing va Speaking — har biri o\'z vaqti bilan.' },
  { title: 'Natijangizni oling', desc: 'Yakuniy natijangiz tayyor bo‘lgach, PDF hisobotni oling.' },
]

const faqs: [string, string][] = [
  ['Mock imtihon nima uchun kerak?', 'Mock imtihon — haqiqiy CEFR Multilevel imtihonining formatini, vaqt chegarasini va savol turlarini his qilish uchun mo\'ljallangan mashq sessiyasi. Bu sizga haqiqiy imtihonda o\'zingizni ishonchli his qilishga yordam beradi.'],
  ['Natijam qaysi darajaga to\'g\'ri keladi?', 'Har bir bo\'lim (Reading, Listening, Writing, Speaking) alohida baholanadi va Rasch metodi asosida umumiy CEFR darajangiz (A2dan C1gacha) aniqlanadi.'],
  ['Speaking bo\'limi qanday baholanadi?', 'Speaking javoblaringiz audio formatda yuklanadi va malakali baholovchi tomonidan fluency, lexical resource, grammar va pronunciation mezonlari asosida baholanadi.'],
  ['Natijamni PDF holida olsam bo\'ladimi?', 'Ha, har bir yakunlangan mock imtihon uchun to\'liq natija hisobotini PDF formatda yuklab olishingiz mumkin.'],
]

function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2.5 font-bold tracking-tight">
      <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
        <span className="text-sm font-bold">S</span>
      </span>
      <span>Mock Center<span className="text-primary">.</span></span>
    </Link>
  )
}

function Footer() {
  return (
    <footer className="border-t bg-card">
      <div className="container-shell flex flex-col justify-between gap-8 py-10 text-sm text-muted-foreground sm:flex-row">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs leading-6">Qog‘oz va speaking formatidagi mock imtihonlarni boshqaruvchi markaz.</p>
        </div>
        <div className="flex gap-10">
          <div className="flex flex-col gap-2">
            <span className="font-semibold text-foreground">Platforma</span>
            <Link href="/mock">Mock imtihonlar</Link>
            <Link href="/exams">Imtihon haqida</Link>
            <Link href="/about">Biz haqimizda</Link>
          </div>
          <div className="flex flex-col gap-2">
            <span className="font-semibold text-foreground">Hisob</span>
            <Link href="/login">Kirish</Link>
            <Link href="/register">Ro'yxatdan o'tish</Link>
            <Link href="/result">Natijani tekshirish</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

function MockExamsPreview() {
  const [exams, setExams] = useState<MockExam[] | null>(null)
  const [errored, setErrored] = useState(false)

  useEffect(() => {
    publicApi.mockExams().then((data) => setExams(data.slice(0, 3))).catch(() => setErrored(true))
  }, [])

  if (errored) return null

  return (
    <section className="border-y bg-card py-20">
      <div className="container-shell">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">Mock imtihonlar</p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">Haqiqiy formatda mashq qiling.</h2>
            <p className="mt-4 leading-7 text-muted-foreground">Har bir mock imtihon Reading, Listening, Writing va Speaking bo'limlaridan iborat va CEFR darajangizni aniq ko'rsatadi.</p>
          </div>
          <Link href="/mock" className="hidden shrink-0 items-center gap-2 rounded-lg border bg-card px-4 py-2.5 text-sm font-semibold hover:bg-muted sm:inline-flex">
            Barchasini ko'rish <ArrowRight className="size-4" />
          </Link>
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {exams === null &&
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="surface h-56 animate-pulse p-6" />
            ))}
          {exams?.length === 0 && (
            <p className="col-span-full text-sm text-muted-foreground">Hozircha faol mock imtihonlar yo'q. Tez orada qo'shiladi.</p>
          )}
          {exams?.map((exam) => (
            <div key={exam.id} className="surface flex flex-col p-6">
              <div className="flex items-center justify-between">
                <div className="flex size-11 items-center justify-center rounded-xl bg-secondary text-primary">
                  <Play className="size-5" />
                </div>
                <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-semibold text-muted-foreground">{exam.cefr_level}</span>
              </div>
              <h3 className="mt-5 text-lg font-bold">{exam.title}</h3>
              <div className="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Clock3 className="size-3.5" />4 bo'lim</span>
                <span className="font-semibold text-foreground">
                  {exam.price > 0 ? `${exam.price.toLocaleString('uz-UZ')} so'm` : 'Bepul'}
                </span>
              </div>
              <Link
                href={`/mock/${exam.id}`}
                className="mt-6 flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
              >
                <Play className="size-4" /> Batafsil
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default function PlatformHome() {
  return (
    <div className="min-h-screen">
      <SiteHeader variant="public" />
      <main>
        <section className="container-shell grid gap-14 pb-20 pt-16 lg:grid-cols-[1.1fr_.9fr] lg:items-center lg:pb-28 lg:pt-24">
          <div>
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1.5 text-xs font-semibold text-primary">
              <span className="size-1.5 rounded-full bg-accent" />
              Ro'yxatdan o'tish ochiq
            </div>
            <h1 className="max-w-3xl text-balance text-5xl font-bold tracking-[-0.04em] text-foreground sm:text-6xl lg:text-7xl">
              Ingliz tilini rivojlantiring. <span className="text-primary">Darajangizni isbotlang.</span>
            </h1>
            <p className="mt-7 max-w-xl text-pretty text-lg leading-8 text-muted-foreground">
              Reading, Listening, Writing va Speaking bo‘limlarini mock formatida topshiring va yakuniy natijangizni oling.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/register" className="rounded-lg bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm hover:bg-primary/90">
                Bepul boshlash <ArrowRight className="ml-2 inline size-4" />
              </Link>
              <Link href="/mock" className="rounded-lg border bg-card px-5 py-3.5 text-sm font-semibold hover:bg-muted">
                <Play className="mr-2 inline size-4 text-primary" />Mock imtihonni ko'rish
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted-foreground">
              <span><ShieldCheck className="mr-2 inline size-4 text-accent" />Xavfsiz hisob va to'lov</span>
              <span><LockKeyhole className="mr-2 inline size-4 text-accent" />Aniq natija tizimi</span>
            </div>
          </div>

          <div className="relative">
            <div className="surface overflow-hidden bg-primary p-6 text-primary-foreground sm:p-8">
              <div className="flex items-center justify-between border-b border-primary-foreground/20 pb-6">
                <div>
                  <p className="text-sm text-primary-foreground/70">Sizning yo'lingiz</p>
                  <p className="mt-1 text-xl font-semibold">Bitta aniq platforma</p>
                </div>
                <Sparkles className="size-5 text-primary-foreground/70" />
              </div>
              <div className="py-8">
                <div className="flex items-center gap-4">
                  <div className="flex size-11 items-center justify-center rounded-full bg-primary-foreground text-primary"><Check /></div>
                  <div>
                    <p className="font-semibold">Ro'yxatdan o'tish</p>
                    <p className="text-sm text-primary-foreground/70">Bir necha daqiqada hisob oching</p>
                  </div>
                </div>
                <div className="ml-5 h-10 border-l border-dashed border-primary-foreground/30" />
                <div className="flex items-center gap-4">
                  <div className="flex size-11 items-center justify-center rounded-full border border-primary-foreground/40 text-sm font-semibold">02</div>
                  <div>
                    <p className="font-semibold">Mock imtihon</p>
                    <p className="text-sm text-primary-foreground/70">Reading, Listening, Writing, Speaking</p>
                  </div>
                </div>
                <div className="ml-5 h-10 border-l border-dashed border-primary-foreground/30" />
                <div className="flex items-center gap-4">
                  <div className="flex size-11 items-center justify-center rounded-full border border-primary-foreground/40 text-sm font-semibold">03</div>
                  <div>
                    <p className="font-semibold">CEFR natija</p>
                    <p className="text-sm text-primary-foreground/70">PDF hisobot bilan</p>
                  </div>
                </div>
              </div>
              <div className="rounded-lg bg-primary-foreground/10 p-4 text-sm leading-6 text-primary-foreground/80">
                Barcha jarayoningiz — ro'yxatdan o'tishdan natijagacha — bitta joyda.
              </div>
            </div>
            <div className="absolute -bottom-5 -left-5 hidden rounded-xl border bg-card p-4 shadow-lg sm:block">
              <div className="flex items-center gap-3">
                <div className="flex size-9 items-center justify-center rounded-lg bg-emerald-50 text-accent"><Users className="size-4" /></div>
                <div>
                  <p className="text-xs text-muted-foreground">Faol foydalanuvchilar</p>
                  <p className="text-sm font-semibold">Har kuni o'sib bormoqda</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <MockExamsPreview />

        <section className="container-shell py-20">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary">Imtihon tuzilishi</p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">To'rtta bo'lim. Bitta to'liq rasm.</h2>
            <p className="mt-4 leading-7 text-muted-foreground">Har bir bo'lim ingliz tilidagi amaliy muloqotning turli qirralarini baholaydi.</p>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {skillCards.map(({ icon: Icon, title, tag, copy, accent }) => (
              <div key={title} className={`rounded-xl border p-6 transition-shadow hover:shadow-md ${accent ? 'border-primary/30 bg-blue-50/50' : 'bg-card'}`}>
                <div className={`flex size-11 items-center justify-center rounded-lg ${accent ? 'bg-primary text-primary-foreground' : 'bg-muted text-primary'}`}>
                  <Icon className="size-5" />
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <h3 className="font-semibold">{title}</h3>
                  <span className="text-xs font-medium text-muted-foreground">{tag}</span>
                </div>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">{copy}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="border-y bg-card py-20">
          <div className="container-shell">
            <div className="max-w-2xl">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">Qanday ishlaydi</p>
              <h2 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">Ro'yxatdan o'tishdan natijagacha.</h2>
            </div>
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {steps.map((s, i) => (
                <div key={s.title} className="surface p-6">
                  <span className="flex size-9 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{i + 1}</span>
                  <p className="mt-5 font-semibold">{s.title}</p>
                  <p className="mt-2 text-sm leading-6 text-muted-foreground">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-primary py-16 text-primary-foreground">
          <div className="container-shell flex flex-col justify-between gap-8 sm:flex-row sm:items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Keyingi qadamga tayyormisiz?</h2>
              <p className="mt-2 text-primary-foreground/70">Mock imtihonni tanlang va bugunoq mashq qilishni boshlang.</p>
            </div>
            <Link href="/mock" className="rounded-lg bg-primary-foreground px-5 py-3.5 text-center text-sm font-semibold text-primary shadow-sm hover:bg-primary-foreground/90">
              Mock imtihonlarni ko'rish <ArrowRight className="ml-2 inline size-4" />
            </Link>
          </div>
        </section>

        <section className="container-shell py-20">
          <div className="mx-auto max-w-3xl">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">Savollar</p>
              <h2 className="mt-3 text-3xl font-bold tracking-tight">Tez-tez so'raladigan savollar</h2>
            </div>
            <div className="mt-10 divide-y rounded-xl border bg-card">
              {faqs.map(([q, a]) => (
                <details key={q} className="group p-5">
                  <summary className="flex cursor-pointer list-none items-center justify-between font-semibold">
                    <span>{q}</span>
                    <ChevronDown className="size-4 text-muted-foreground transition-transform group-open:rotate-180" />
                  </summary>
                  <p className="max-w-2xl pt-3 text-sm leading-6 text-muted-foreground">{a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

import Link from 'next/link'
import { BookOpen, Headphones, Mic2, PenLine } from 'lucide-react'

const COLUMNS: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: 'Platforma',
    links: [
      { href: '/mock', label: 'Mock imtihonlar' },
      { href: '/exams', label: 'Imtihon qanday o‘tadi' },
      { href: '/speaking', label: 'Speaking' },
      { href: '/result', label: 'Natijani tekshirish' },
    ],
  },
  {
    title: 'Hisob',
    links: [
      { href: '/login', label: 'Kirish' },
      { href: '/register', label: "Ro'yxatdan o'tish" },
      { href: '/dashboard', label: 'Shaxsiy kabinet' },
    ],
  },
  {
    title: "Ma'lumot",
    links: [
      { href: '/about', label: 'Biz haqimizda' },
    ],
  },
]

const SKILLS = [
  { icon: BookOpen, label: 'Reading' },
  { icon: Headphones, label: 'Listening' },
  { icon: PenLine, label: 'Writing' },
  { icon: Mic2, label: 'Speaking' },
]

export function SiteFooter() {
  return (
    <footer className="border-t bg-card">
      <div className="container-shell py-12 sm:py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2.5 font-bold tracking-tight">
              <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <span className="text-sm font-bold">S</span>
              </span>
              <span>Steply<span className="text-primary">.</span></span>
            </Link>
            <p className="mt-4 max-w-sm text-sm leading-6 text-muted-foreground">
              CEFR Multilevel imtihoniga real formatga yaqin tayyorgarlik: qog‘ozda Reading/Listening/Writing
              va kompyuterda Speaking mock-testlari.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {SKILLS.map(({ icon: Icon, label }) => (
                <span key={label} className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-primary">
                  <Icon className="size-3.5" /> {label}
                </span>
              ))}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <p className="text-sm font-semibold">{col.title}</p>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-muted-foreground hover:text-foreground">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t pt-6 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} Steply. Barcha huquqlar himoyalangan.</p>
          <p>Mock Center formati — qog‘ozda Reading/Listening/Writing, kompyuterda Speaking.</p>
        </div>
      </div>
    </footer>
  )
}

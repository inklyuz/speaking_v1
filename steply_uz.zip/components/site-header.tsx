'use client'

import Link from 'next/link'
import { useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { ArrowRight, LogOut, Menu } from 'lucide-react'
import { useAuth } from '@/lib/auth/auth-context'

type SiteHeaderVariant = 'public' | 'dashboard'

type NavLink = { href: string; label: string }

const PUBLIC_LINKS: NavLink[] = [
  { href: '/mock', label: 'Mock imtihonlar' },
  { href: '/exams', label: 'Imtihon haqida' },
  { href: '/speaking', label: 'Speaking' },
  { href: '/result', label: 'Natijalar' },
]

const DASHBOARD_LINKS: NavLink[] = [
  { href: '/mock', label: 'Mock imtihonlar' },
  { href: '/exams', label: 'Imtihon haqida' },
  { href: '/dashboard', label: 'Kabinet' },
]

function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2.5 font-bold tracking-tight">
      <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
        <span className="text-sm font-bold">S</span>
      </span>
      <span>Steply<span className="text-primary">.</span></span>
    </Link>
  )
}

/**
 * Sayt bo'ylab yagona umumiy navbar.
 * Har bir sahifa o'zining <header> kodini yozish o'rniga shu komponentdan foydalanadi.
 *
 * variant="public"    — bosh sahifa, /about, /exams, /result, /mock kabi ochiq sahifalar uchun
 * variant="dashboard" — /dashboard, /mock/[id]/result kabi tizimga kirgan foydalanuvchi sahifalari uchun
 */
export function SiteHeader({ variant = 'public' }: { variant?: SiteHeaderVariant }) {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const { user, isAuthenticated, isLoading, logout } = useAuth()

  const links = variant === 'dashboard' ? DASHBOARD_LINKS : PUBLIC_LINKS

  async function handleLogout() {
    await logout()
    router.push('/')
  }

  return (
    <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur-sm">
      <div className="container-shell flex h-16 items-center justify-between md:h-18">
        <Logo />

        <nav className="hidden items-center gap-8 text-sm font-medium text-muted-foreground md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={pathname === link.href ? 'text-foreground' : 'hover:text-foreground'}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          {variant === 'dashboard' ? (
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 rounded-lg border bg-card px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
            >
              <LogOut className="size-4" /> Chiqish
            </button>
          ) : !isLoading && isAuthenticated ? (
            <Link
              href="/dashboard"
              className="rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm hover:bg-primary/90"
            >
              {user?.profile?.full_name?.split(' ')[0] ?? 'Kabinet'} <ArrowRight className="ml-2 inline size-4" />
            </Link>
          ) : (
            <>
              <Link href="/login" className="rounded-lg px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-muted">
                Kirish
              </Link>
              <Link
                href="/register"
                className="rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm hover:bg-primary/90"
              >
                Ro'yxatdan o'tish <ArrowRight className="ml-2 inline size-4" />
              </Link>
            </>
          )}
        </div>

        <button aria-label="Menyu" onClick={() => setOpen((v) => !v)} className="rounded-lg p-2 hover:bg-muted md:hidden">
          <Menu />
        </button>
      </div>

      {open && (
        <nav className="container-shell flex flex-col gap-4 border-t py-5 text-sm font-medium md:hidden">
          {links.map((link) => (
            <Link key={link.href} href={link.href} onClick={() => setOpen(false)}>
              {link.label}
            </Link>
          ))}
          {variant === 'dashboard' ? (
            <button onClick={handleLogout} className="text-left text-red-600">Chiqish</button>
          ) : !isLoading && isAuthenticated ? (
            <Link href="/dashboard" onClick={() => setOpen(false)} className="text-primary">Kabinet</Link>
          ) : (
            <>
              <Link href="/login" onClick={() => setOpen(false)}>Kirish</Link>
              <Link href="/register" onClick={() => setOpen(false)} className="text-primary">Ro'yxatdan o'tish</Link>
            </>
          )}
        </nav>
      )}
    </header>
  )
}

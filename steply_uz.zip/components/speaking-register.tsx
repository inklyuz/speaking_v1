"use client"

import Link from "next/link"
import { useEffect, useRef, useState } from "react"
import { useSearchParams } from "next/navigation"
import { ArrowLeft, User, AlertCircle, MessageCircle, Phone } from "lucide-react"
import { apiRequest } from "@/lib/api/client"

type RegisterInitResponse = {
  status: string
  message?: string | null
  expires_in_seconds?: number | null
  bot_link?: string | null
  debug_code?: string | null
}

type Channel = "sms" | "telegram"

export function SpeakingRegister() {
  const searchParams = useSearchParams()
  const testId = searchParams.get("id") ?? ""

  // 1-bosqich maydonlari
  const [phone, setPhone] = useState("+998")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [birthDate, setBirthDate] = useState("")
  const [gender, setGender] = useState<"male" | "female">("male")
  const [channel, setChannel] = useState<Channel>("sms")

  // Umumiy holat
  const [step, setStep] = useState<"form" | "verify">("form")
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  // 2-bosqich (kod tasdiqlash) holati
  const [code, setCode] = useState("")
  const [botLink, setBotLink] = useState<string | null>(null)
  const [debugCode, setDebugCode] = useState<string | null>(null)
  const [expiresAt, setExpiresAt] = useState<number | null>(null)
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null)
  const [resendCooldown, setResendCooldown] = useState(0)
  const cooldownTimer = useRef<number | null>(null)

  useEffect(() => {
    if (expiresAt == null) {
      setSecondsLeft(null)
      return
    }
    const id = window.setInterval(() => {
      const left = Math.max(0, Math.round((expiresAt - Date.now()) / 1000))
      setSecondsLeft(left)
      if (left <= 0) window.clearInterval(id)
    }, 1000)
    return () => window.clearInterval(id)
  }, [expiresAt])

  useEffect(() => {
    if (resendCooldown <= 0) {
      if (cooldownTimer.current) window.clearInterval(cooldownTimer.current)
      return
    }
    cooldownTimer.current = window.setInterval(() => {
      setResendCooldown((v) => (v <= 1 ? 0 : v - 1))
    }, 1000)
    return () => {
      if (cooldownTimer.current) window.clearInterval(cooldownTimer.current)
    }
  }, [resendCooldown])

  const applyInitResponse = (res: RegisterInitResponse) => {
    setBotLink(res.bot_link ?? null)
    setDebugCode(res.debug_code ?? null)
    setExpiresAt(res.expires_in_seconds ? Date.now() + res.expires_in_seconds * 1000 : null)
    // Backendda qayta yuborish uchun 5 daqiqalik cooldown bor — mos ravishda ko'rsatamiz
    setResendCooldown(5 * 60)
    setStep("verify")
  }

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault()
    setError(null)
    setLoading(true)

    try {
      const res = await apiRequest<RegisterInitResponse>("/auth/register", {
        method: "POST",
        body: JSON.stringify({
          phone,
          password,
          full_name: fullName,
          birth_date: birthDate,
          gender,
          channel,
        }),
      })

      applyInitResponse(res)
    } catch (err: any) {
      setError(err.message || "Xatolik yuz berdi")
    } finally {
      setLoading(false)
    }
  }

  const handleResend = async () => {
    if (resendCooldown > 0) return
    setError(null)
    setLoading(true)
    try {
      const res = await apiRequest<RegisterInitResponse>("/auth/register", {
        method: "POST",
        body: JSON.stringify({
          phone,
          password,
          full_name: fullName,
          birth_date: birthDate,
          gender,
          channel,
        }),
      })
      applyInitResponse(res)
    } catch (err: any) {
      // Backend cooldown/blok bo'lsa 429 xato matnini shu yerda ko'rsatamiz
      setError(err.message || "Xatolik yuz berdi")
    } finally {
      setLoading(false)
    }
  }

  const handleVerify = async (e?: React.FormEvent) => {
    e?.preventDefault()
    setError(null)
    setLoading(true)

    try {
      await apiRequest("/auth/register/verify", {
        method: "POST",
        body: JSON.stringify({ phone, code }),
      })

      setSuccess(true)
    } catch (err: any) {
      setError(err.message || "Kod noto'g'ri yoki eskirgan")
    } finally {
      setLoading(false)
    }
  }

  const backHref = testId ? `/speaking/login?id=${testId}` : "/speaking/login"

  if (success) {
    return (
      <main className="min-h-screen bg-card flex flex-col items-center justify-center p-5">
        <div className="mx-auto max-w-md w-full bg-background rounded-xl border p-8 text-center shadow-sm">
          <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 mb-4">
            <User className="size-7" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Muvaffaqiyatli!</h1>
          <p className="text-muted-foreground mb-6">
            Siz muvaffaqiyatli ro'yxatdan o'tdingiz. Tizimga kirishingiz mumkin.
          </p>
          <Link href={backHref} className="block w-full rounded-lg bg-primary py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
            Kirish sahifasiga o'tish
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-card">
      <header className="border-b">
        <div className="container-shell flex items-center justify-between py-3">
          <Link
            href={backHref}
            onClick={(e) => {
              if (step === "verify") {
                e.preventDefault()
                setStep("form")
                setError(null)
              }
            }}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <span className="text-sm text-muted-foreground">Ro'yxatdan o'tish</span>
        </div>
      </header>
      <div className="mx-auto max-w-md px-5 py-12">
        <div className="flex size-14 items-center justify-center rounded-full bg-primary/10">
          <User className="size-7 text-primary" />
        </div>

        {step === "form" ? (
          <>
            <h1 className="mt-4 text-2xl font-bold">Yangi hisob ochish</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Platformaga kirish uchun ma'lumotlaringizni kiriting.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">To'liq ismingiz</label>
                <input
                  type="text"
                  required
                  minLength={2}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Falonchiyev Pistonchi"
                  className="w-full rounded-lg border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium">Telefon raqam</label>
                <input
                  type="text"
                  required
                  pattern="^\+998\d{9}$"
                  title="+998XXXXXXXXX formatida bo'lishi kerak"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+998901234567"
                  className="w-full rounded-lg border bg-background px-4 py-3 text-sm font-mono outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Tug'ilgan sana</label>
                  <input
                    type="date"
                    required
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full rounded-lg border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Jins</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as "male" | "female")}
                    className="w-full rounded-lg border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="male">Erkak</option>
                    <option value="female">Ayol</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium">Yangi parol o'ylab toping</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Kamida 6 ta belgi"
                  className="w-full rounded-lg border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium">Tasdiqlash kodini qanday olmoqchisiz?</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setChannel("sms")}
                    className={`flex items-center justify-center gap-2 rounded-lg border py-3 text-sm font-semibold ${
                      channel === "sms" ? "border-primary bg-primary/10 text-primary" : "text-muted-foreground"
                    }`}
                  >
                    <Phone className="size-4" /> SMS
                  </button>
                  <button
                    type="button"
                    onClick={() => setChannel("telegram")}
                    className={`flex items-center justify-center gap-2 rounded-lg border py-3 text-sm font-semibold ${
                      channel === "telegram" ? "border-primary bg-primary/10 text-primary" : "text-muted-foreground"
                    }`}
                  >
                    <MessageCircle className="size-4" /> Telegram
                  </button>
                </div>
              </div>

              {error && (
                <p className="flex items-center gap-1.5 text-xs text-red-500">
                  <AlertCircle className="size-3.5" /> {error}
                </p>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-lg bg-primary py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              >
                {loading ? "Kutilmoqda..." : "Davom etish"}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-muted-foreground">
              Hisobingiz bormi? <Link href={backHref} className="text-primary font-medium hover:underline">Tizimga kiring</Link>
            </p>
          </>
        ) : (
          <>
            <h1 className="mt-4 text-2xl font-bold">Kodni tasdiqlang</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              <span className="font-mono">{phone}</span> raqamiga{" "}
              {channel === "telegram" ? "Telegram orqali" : "SMS orqali"} 6 xonali kod yuborildi.
              {secondsLeft != null && secondsLeft > 0 && (
                <> Kod {Math.floor(secondsLeft / 60)}:{String(secondsLeft % 60).padStart(2, "0")} davomida amal qiladi.</>
              )}
            </p>

            {channel === "telegram" && botLink && (
              <a
                href={botLink}
                target="_blank"
                rel="noreferrer"
                className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-primary/40 bg-primary/5 py-3 text-sm font-semibold text-primary hover:bg-primary/10"
              >
                <MessageCircle className="size-4" /> Telegram botni ochish
              </a>
            )}

            {debugCode && (
              <p className="mt-3 rounded-lg bg-muted/60 px-4 py-2 text-xs text-muted-foreground">
                Dev rejim: kod — <span className="font-mono font-semibold">{debugCode}</span>
              </p>
            )}

            <form onSubmit={handleVerify} className="mt-6 space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">Tasdiqlash kodi</label>
                <input
                  type="text"
                  required
                  inputMode="numeric"
                  minLength={6}
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                  placeholder="123456"
                  className="w-full rounded-lg border bg-background px-4 py-3 text-center text-lg font-mono tracking-widest outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              {error && (
                <p className="flex items-center gap-1.5 text-xs text-red-500">
                  <AlertCircle className="size-3.5" /> {error}
                </p>
              )}

              <button
                type="submit"
                disabled={loading || code.length !== 6}
                className="w-full rounded-lg bg-primary py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              >
                {loading ? "Tekshirilmoqda..." : "Tasdiqlash"}
              </button>

              <button
                type="button"
                onClick={handleResend}
                disabled={loading || resendCooldown > 0}
                className="w-full rounded-lg border py-3 text-sm font-semibold text-muted-foreground hover:bg-muted/40 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {resendCooldown > 0
                  ? `Qayta yuborish (${Math.floor(resendCooldown / 60)}:${String(resendCooldown % 60).padStart(2, "0")})`
                  : "Kodni qayta yuborish"}
              </button>
            </form>
          </>
        )}
      </div>
    </main>
  )
}

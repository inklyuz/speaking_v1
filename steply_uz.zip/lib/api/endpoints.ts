import { apiDelete, apiGet, apiPatch, apiPost, apiPostForm, apiPut, baseUrl, notifyAuthChanged } from './client'
import type {
  AdminStatistics, AnswerKeyResponse, AssignedSpeakingTest, AuthToken, ExamSession, ExamSessionCreateInput,
  ExamVersion, ListeningCreateInput, ListeningResultDetail, ListeningResultSummary, ListeningSubmitInput,
  ListeningTest, ListeningUpdateInput, LockResult,
  LoginResponse, Me, MockAttemptStart, MockExam, MockExamCreateInput, MockExamUpdateInput,
  MockFinalResult, MockSkillStatus, ReadingCreateInput, ReadingResultDetail,
  ReadingResultSummary, ReadingSubmitInput, ReadingTest, ReadingUpdateInput, RegisterForSessionInput,
  RegisterResponse, RegisterVerifyResponse, Session, SessionRegistration, SkillType,
  SpeakingResult, SpeakingResultInput, SpeakingSubmission, SpeakingTest, SpeakingTestCreateInput,
  SpeakingTestSummary, SpeakingTestUpdateInput, StatusMessage, UserProfile, WritingExam,
  WritingResult, WritingSubmitInput, WritingPendingItem, PublicExamDetail, PublicExamSession, PublicSessionDetail, PublicStats, VerifiedResult,
} from './types'

// ============ AUTH ============

export const authApi = {
  me: () => apiGet<Me>('/auth/me'),

  sendOtp: (input: { phone: string; channel?: 'sms' | 'telegram'; purpose?: 'register' | 'reset_password' }) =>
    apiPost<StatusMessage>('/auth/otp/send', input, { anonymous: true }),

  // Login/register javobida token bo'lsa ham, uni frontend saqlamaydi —
  // backend javobi bilan bir vaqtda access_token/refresh_token httpOnly
  // cookie'ga yozadi (auth/router.py: set_auth_cookies). Shu sabab bu yerda
  // faqat notifyAuthChanged() chaqiriladi — AuthProvider /auth/me orqali
  // yangi holatni o'zi yuklab oladi.
  phoneLogin: async (phone: string, password: string) => {
    const res = await apiPost<LoginResponse>('/auth/phone/login', { phone, password }, { anonymous: true })
    if (res.status === 'success') notifyAuthChanged()
    return res
  },

  register: (input: { phone: string; password: string; full_name: string; birth_date: string; gender: 'male' | 'female'; channel?: 'sms' | 'telegram' }) =>
    apiPost<RegisterResponse>('/auth/register', input, { anonymous: true }),

  registerVerify: async (input: { phone: string; code: string }) => {
    const res = await apiPost<RegisterVerifyResponse>('/auth/register/verify', input, { anonymous: true })
    if (res.status === 'success') notifyAuthChanged()
    return res
  },

  forgotPassword: (phone: string) => apiPost<StatusMessage>('/auth/password/forgot', { phone }, { anonymous: true }),

  resetPassword: (input: { phone: string; code: string; new_password: string }) =>
    apiPost<StatusMessage>('/auth/password/reset', input, { anonymous: true }),

  logout: async () => {
    try { await apiPost<StatusMessage>('/auth/logout') } finally { notifyAuthChanged() }
  },

  refresh: () => apiPost<StatusMessage>('/auth/refresh', undefined, { anonymous: true, skipAuthRetry: true }),
}

// ============ MY PROFILE ============

export const profileApi = {
  me: () => apiGet<Me>('/users/me/'),
  update: (input: Partial<Pick<UserProfile, 'full_name' | 'username' | 'bio' | 'birth_date' | 'language' | 'timezone'>>) =>
    apiPut<Me>('/users/me/profile', input),
  uploadAvatar: (file: File) => {
    const form = new FormData()
    form.append('file', file)
    return apiPostForm<{ avatar_url: string }>('/users/me/avatar', form)
  },
  contacts: () => apiGet<Me['contacts']>('/users/me/contacts'),
  addContact: (input: { contact_type: 'email' | 'phone'; value: string }) =>
    apiPost<void>('/users/me/contacts', input),
  setPrimaryContact: (contactId: number) => apiPatch<void>(`/users/me/contacts/${contactId}/primary`),
  deleteContact: (contactId: number) => apiDelete<void>(`/users/me/contacts/${contactId}`),
  sessions: () => apiGet<Session[]>('/users/me/sessions'),
  revokeSession: (sessionId: string) => apiDelete<void>(`/users/me/sessions/${sessionId}`),
}

// ============ PUBLIC MOCK CENTER ============

export const publicApi = {
  mockExams: () => apiGet<MockExam[]>('/public/mock-exams', { anonymous: true }),
  mockExam: (examId: string) => apiGet<PublicExamDetail>(`/public/mock-exams/${encodeURIComponent(examId)}`, { anonymous: true }),
  examSessions: (examId: string) => apiGet<PublicExamSession[]>(`/public/mock-exams/${encodeURIComponent(examId)}/sessions`, { anonymous: true }),
  sessions: (region?: string) => apiGet<PublicExamSession[]>('/public/sessions', { anonymous: true, query: { region } }),
  session: (sessionId: number) => apiGet<PublicSessionDetail>(`/public/sessions/${sessionId}`, { anonymous: true }),
  stats: () => apiGet<PublicStats>('/public/stats', { anonymous: true }),
  resultByQr: (token: string) => apiGet<VerifiedResult>(`/public/results/by-qr/${encodeURIComponent(token)}`, { anonymous: true }),
}

export const mockCenterApi = {
  myRegistrations: () => apiGet<SessionRegistration[]>('/mock-center/me/registrations'),
  registration: (id: number) => apiGet<Record<string, unknown>>(`/mock-center/me/registrations/${id}`),
  registerForSession: (input: RegisterForSessionInput) => apiPost<SessionRegistration>('/mock-exams/sessions/register', input),
  permitUrl: (id: number) => `${baseUrl}/api/v1/mock-center/me/registrations/${id}/permit.pdf`,
  myResults: () => apiGet<MockFinalResult[]>('/mock-center/me/results'),
  result: (id: number) => apiGet<MockFinalResult>(`/mock-center/me/results/${id}`),
  resultPdfUrl: (id: number) => `${baseUrl}/api/v1/mock-center/me/results/${id}/pdf`,
  checkInSearch: (studentId: string, sessionId?: number) => apiGet<Record<string, unknown>>('/mock-center/admin/check-in/search', { query: { student_id: studentId, session_id: sessionId } }),
  checkIn: (studentId: string, sessionId?: number) => apiPost<Record<string, unknown>>('/mock-center/admin/check-in', { student_id: studentId, session_id: sessionId }),
  attempt: (attemptId: number) => apiGet<Record<string, unknown>>(`/mock-center/admin/attempts/${attemptId}`),
  scoreSkill: (attemptId: number, skill: 'WRITING'|'SPEAKING', scaled_score: number, raw_score?: number) => apiPost<Record<string, unknown>>(`/mock-center/admin/attempts/${attemptId}/skills/${skill}/score`, { scaled_score, raw_score }),
  writingPending: (status: 'pending' | 'graded' | 'all' = 'pending') =>
    apiGet<WritingPendingItem[]>('/mock-center/admin/writing/pending', { query: { status } }),
  finalize: (attemptId: number, send_sms = false) => apiPost<Record<string, unknown>>(`/mock-center/admin/attempts/${attemptId}/finalize`, { send_sms }),
}

// ============ MOCK EXAMS ============

export const mockExamsApi = {
  // --- Admin ---
  adminList: () => apiGet<MockExam[]>('/mock-exams/admin'),
  adminGet: (examId: string) => apiGet<MockExam>(`/mock-exams/admin/${examId}`),
  create: (input: MockExamCreateInput) => apiPost<MockExam>('/mock-exams/admin', input),
  update: (examId: string, input: MockExamUpdateInput) => apiPatch<MockExam>(`/mock-exams/admin/${examId}`, input),
  remove: (examId: string) => apiDelete<void>(`/mock-exams/admin/${examId}`),

  // --- Candidate ---
  getAll: () => apiGet<MockExam[]>('/mock-exams'),
  buy: (examId: string) => apiPost<{ id: number; user_id: number; mock_exam_id: string; is_active: boolean; comment: string; created_at: string }>(`/mock-exams/${examId}/buy`),

  start: (examId: string) => apiPost<MockAttemptStart>(`/mock-exams/${examId}/start`),
  status: (attemptId: number) => apiGet<MockSkillStatus[]>(`/mock-exams/attempts/${attemptId}/status`),
  submitSkill: (attemptId: number, skill: SkillType) => apiPost<void>(`/mock-exams/attempts/${attemptId}/submit/${skill}`),
  finish: (attemptId: number) => apiPost<MockFinalResult>(`/mock-exams/attempts/${attemptId}/finish`),

  resultsHistory: () => apiGet<MockFinalResult[]>('/mock-exams/results/history'),
  result: (attemptId: number) => apiGet<MockFinalResult>(`/mock-exams/attempts/${attemptId}/result`),

  // --- Exam sessions (paper-based, in-person) ---
  createSession: (input: ExamSessionCreateInput) => apiPost<ExamSession>('/mock-exams/admin/sessions', input),
  updateSession: (sessionId: number, input: Partial<ExamSessionCreateInput>) =>
    apiPatch<ExamSession>(`/mock-exams/admin/sessions/${sessionId}`, input),
  adminSessions: (mockExamId?: string) => apiGet<ExamSession[]>('/mock-exams/admin/sessions', { query: { mock_exam_id: mockExamId } }),
  openSessions: (mockExamId?: string) => apiGet<ExamSession[]>('/mock-exams/sessions/open', { query: { mock_exam_id: mockExamId } }),
  sessionRegistrations: (sessionId: number) => apiGet<SessionRegistration[]>(`/mock-exams/admin/sessions/${sessionId}/registrations`),
  confirmAttendance: (registrationId: number) =>
    apiPost<SessionRegistration>(`/mock-exams/admin/registrations/${registrationId}/confirm-attendance`),

  registerForSession: (input: RegisterForSessionInput) => apiPost<SessionRegistration>('/mock-exams/sessions/register', input),
  myRegistrations: () => apiGet<SessionRegistration[]>('/mock-exams/sessions/my-registrations'),

  // --- Paper-based downloads (admin) ---
  listeningPaperUrl: (mockExamId: string) => `${baseUrl}/api/v1/mock-exams/admin/papers/${mockExamId}/listening.pdf`,
  readingPaperUrl: (mockExamId: string) => `${baseUrl}/api/v1/mock-exams/admin/papers/${mockExamId}/reading.pdf`,
  writingPaperUrl: (mockExamId: string) => `${baseUrl}/api/v1/mock-exams/admin/papers/${mockExamId}/writing.pdf`,
  answerSheetsBulkZipUrl: (sessionId: number) => `${baseUrl}/api/v1/mock-exams/admin/papers/sessions/${sessionId}/answer-sheets-bulk.zip`,
  sessionBundleZipUrl: (sessionId: number) => `${baseUrl}/api/v1/mock-exams/admin/papers/sessions/${sessionId}/bundle.zip`,

  // --- AI answer-sheet grading (admin) ---
  gradeAnswerSheets: (images: File[]) => {
    const form = new FormData()
    images.forEach((f) => form.append('images', f))
    return apiPostForm<Record<string, unknown>>('/mock-exams/admin/grade/answer-sheets', form)
  },
  gradeAnswerSheetsWithKeys: (images: File[], input: { listening_answer_key?: string; reading_answer_key?: string; exam_id?: string }) => {
    const form = new FormData()
    images.forEach((f) => form.append('images', f))
    if (input.listening_answer_key) form.append('listening_answer_key', input.listening_answer_key)
    if (input.reading_answer_key) form.append('reading_answer_key', input.reading_answer_key)
    if (input.exam_id) form.append('exam_id', input.exam_id)
    return apiPostForm<Record<string, unknown>>('/mock-exams/admin/grade/answer-sheets/with-keys', form)
  },
  saveGradedAnswerSheets: (input: Record<string, unknown>) => apiPost<Record<string, unknown>>('/mock-exams/admin/grade/answer-sheets/save', input),
  previewAnswerSheet: (image: File) => {
    const form = new FormData()
    form.append('image', image)
    return apiPostForm<Record<string, unknown>>('/mock-exams/admin/grade/answer-sheets/preview', form)
  },
}

// ============ CEFR READING ============

export const readingApi = {
  create: (input: ReadingCreateInput) => apiPost<ReadingTest>('/cefr/all/reading/create', input),
  getAll: () => apiGet<ReadingTest[]>('/cefr/all/reading/get_all'),
  get: (testId: string) => apiGet<ReadingTest>(`/cefr/all/reading/get/${testId}`),
  update: (testId: string, input: ReadingUpdateInput) => apiPut<ReadingTest>(`/cefr/all/reading/update/${testId}`, input),
  remove: (testId: string) => apiDelete<void>(`/cefr/all/reading/delete/${testId}`),
  submit: (testId: string, input: ReadingSubmitInput) => apiPost<ReadingResultDetail>(`/cefr/all/reading/answer/${testId}/submit`, input),
  myResults: () => apiGet<ReadingResultSummary[]>('/cefr/all/reading/my-results/all'),
  resultDetail: (resultId: number) => apiGet<ReadingResultDetail>(`/cefr/all/reading/results/${resultId}`),

  // --- Lock / versions / paper (admin) ---
  answerKey: (testId: string, version?: number) =>
    apiGet<AnswerKeyResponse>(`/cefr/all/reading/${testId}/answer-key`, { query: { version } }),
  versions: (testId: string) => apiGet<ExamVersion[]>(`/cefr/all/reading/${testId}/versions`),
  lock: (testId: string) => apiPost<LockResult>(`/cefr/all/reading/${testId}/lock`),
  paperPdfUrl: (testId: string) => `${baseUrl}/api/v1/cefr/all/reading/${testId}/paper-pdf`,
  answerSheetUrl: (testId: string) => `${baseUrl}/api/v1/cefr/all/reading/${testId}/answer-sheet`,
}

// ============ CEFR LISTENING ============

export const listeningApi = {
  create: (input: ListeningCreateInput) => apiPost<ListeningTest>('/cefr/all/listening/create', input),
  getAll: () => apiGet<ListeningTest[]>('/cefr/all/listening/get_all'),
  get: (examId: string) => apiGet<ListeningTest>(`/cefr/all/listening/get/${examId}`),
  update: (examId: string, input: ListeningUpdateInput) => apiPut<ListeningTest>(`/cefr/all/listening/update/${examId}`, input),
  remove: (examId: string) => apiDelete<void>(`/cefr/all/listening/delete/${examId}`),
  submit: (input: ListeningSubmitInput) => apiPost<ListeningResultDetail>('/cefr/all/listening/answer/submit', input),
  myResults: () => apiGet<ListeningResultSummary[]>('/cefr/all/listening/my-results/all'),
  resultDetail: (resultId: number) => apiGet<ListeningResultDetail>(`/cefr/all/listening/my-results/${resultId}`),

  // --- Lock / versions / paper (admin) ---
  answerKey: (examId: string, version?: number) =>
    apiGet<AnswerKeyResponse>(`/cefr/all/listening/${examId}/answer-key`, { query: { version } }),
  versions: (examId: string) => apiGet<ExamVersion[]>(`/cefr/all/listening/${examId}/versions`),
  lock: (examId: string) => apiPost<LockResult>(`/cefr/all/listening/${examId}/lock`),
  paperPdfUrl: (examId: string) => `${baseUrl}/api/v1/cefr/all/listening/${examId}/paper-pdf`,
  answerSheetUrl: (examId: string) => `${baseUrl}/api/v1/cefr/all/listening/${examId}/answer-sheet`,
  uploadAudio: (file: File) => { const form = new FormData(); form.append('file', file); return apiPostForm<{url:string;filename:string;size:number}>('/cefr/all/listening/audio/upload', form) },
}

// ============ WRITING ============

export const writingApi = {
  create: (input: Record<string, unknown>) => apiPost<WritingExam>('/cefr/all/writing/create', input),
  getAll: () => apiGet<WritingExam[]>('/cefr/all/writing/get_all'),
  get: (examId: string) => apiGet<WritingExam>(`/cefr/all/writing/get/${examId}`),
  update: (examId: string, input: Record<string, unknown>) => apiPut<WritingExam>(`/cefr/all/writing/update/${examId}`, input),
  remove: (examId: string) => apiDelete<void>(`/cefr/all/writing/delete/${examId}`),
  submit: (examId: string, input: WritingSubmitInput) => apiPost<WritingResult>(`/cefr/all/writing/exams/${examId}/submit`, input),
  myResults: () => apiGet<WritingResult[]>('/cefr/all/writing/my-results/all'),
  result: (resultId: number) => apiGet<WritingResult>(`/cefr/all/writing/results/${resultId}`),
  resultPdfUrl: (resultId: number) => `${baseUrl}/api/v1/cefr/all/writing/results/${resultId}/pdf`,

  // Scoring rubric formats (admin)
  createFormat: (input: Record<string, unknown>) => apiPost<Record<string, unknown>>('/cefr/all/writing/formats/create', input),
  getAllFormats: () => apiGet<Record<string, unknown>[]>('/cefr/all/writing/formats/get_all'),
  getFormat: (formatId: number) => apiGet<Record<string, unknown>>(`/cefr/all/writing/formats/get/${formatId}`),
  removeFormat: (formatId: number) => apiDelete<void>(`/cefr/all/writing/formats/delete/${formatId}`),
}

// ============ SPEAKING ============

export const speakingApi = {
  listTests: () => apiGet<SpeakingTestSummary[]>('/speaking/tests'),
  createTest: (input: SpeakingTestCreateInput) => apiPost<SpeakingTest>('/speaking/tests', input),
  getTest: (testId: string) => apiGet<SpeakingTest>(`/speaking/tests/${testId}`),
  updateTest: (testId: string, input: SpeakingTestUpdateInput) => apiPut<SpeakingTest>(`/speaking/tests/${testId}`, input),
  removeTest: (testId: string) => apiDelete<void>(`/speaking/tests/${testId}`),

  assignedTest: (mockSkillAttemptId: number) => apiGet<AssignedSpeakingTest>(`/speaking/attempt/${mockSkillAttemptId}/assigned-test`),
  myAssignedTest: () => apiGet<AssignedSpeakingTest>('/speaking/me/assigned-test'),
  submitAudio: (speakingTestId: string, file: File | Blob, mockSkillAttemptId?: number) => {
    const form = new FormData()
    form.append('file', file, 'answer.webm')
    return apiPostForm<SpeakingSubmission>(`/speaking/${speakingTestId}/submit`, form, { query: { mock_skill_attempt_id: mockSkillAttemptId } })
  },

  pendingSubmissions: () => apiGet<SpeakingSubmission[]>('/speaking/pending'),
  submitResult: (submissionId: number, input: SpeakingResultInput) => apiPost<SpeakingResult>(`/speaking/${submissionId}/result`, input),
}

// ============ ADMIN ============

export const adminApi = {
  checkInSearch: (studentId: string, sessionId?: number) => apiGet<Record<string, unknown>>('/mock-center/admin/check-in/search', { query: { student_id: studentId, session_id: sessionId } }),
  checkIn: (studentId: string, sessionId?: number) => apiPost<Record<string, unknown>>('/mock-center/admin/check-in', { student_id: studentId, session_id: sessionId }),
  attempt: (attemptId: number) => apiGet<Record<string, unknown>>(`/mock-center/admin/attempts/${attemptId}`),
  scoreSkill: (attemptId: number, skill: 'WRITING'|'SPEAKING', scaled_score: number, raw_score?: number) => apiPost<Record<string, unknown>>(`/mock-center/admin/attempts/${attemptId}/skills/${skill}/score`, { scaled_score, raw_score }),
  finalize: (attemptId: number, send_sms = false) => apiPost<Record<string, unknown>>(`/mock-center/admin/attempts/${attemptId}/finalize`, { send_sms }),
  statistics: () => apiGet<AdminStatistics>('/admin/statistics'),
  exportUsersUrl: () => `${baseUrl}/api/v1/admin/export/users`,
}

// ============ SYSTEM ============
// Root va health-check /api/v1 prefiksisiz, shuning uchun to'g'ridan-to'g'ri fetch qilinadi.

export const systemApi = {
  root: () => fetch(`${baseUrl}/`).then((r) => r.json()),
  health: () => fetch(`${baseUrl}/health`).then((r) => r.json()),
}
